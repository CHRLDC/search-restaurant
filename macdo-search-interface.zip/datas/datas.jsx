/**
 * datas\datas.jsx
 * Rôle: Fonctions pour la gestion des requêtes API
 */

// URL de l'API Nominatim
const urlNominatim = 'https://nominatim.openstreetmap.org';

/**
 * Rôle: Rechercher des villes
 * @param {string} keyword - le nom de la ville
 * @returns {Promise<Array>} - data des villes trouvées
 */
export async function searchCitiesByKeyword(keyword) {
    try {
        const response = await fetch(`${urlNominatim}/search?q=${encodeURIComponent(keyword)}&format=json&addressdetails=1&limit=2`);
        if (!response.ok) {
            throw new Error(`Erreur: ${response.statusText}`);
        }
        const data = await response.json();
        const cities = data.filter(item =>
            item.addresstype !== 'suburb' &&
            item.addresstype !== 'municipality'
        );
        if (cities.length === 0) {
            alert(`${keyword} n'a pas été trouvée...`);
            return [];
        }
        return cities.map(item => ({
            name: item.name,
            display_name: item.display_name,
            country: item.address.country,
            department: item.address.state,
            code_post: item.address.postcode,
            position: {
                latitude: item.lat,
                longitude: item.lon
            },
            city_id: item.place_id
        }));
    } catch (error) {
        console.error(error);
        return [];
    }
}

/**
* Rôle: Rechercher une ville par les coordonnées(latitude, longitude)
* @param { Object } location - L'objet contenant la latitude et la longitude
* @returns { Promise < Object >} - Les données de la ville trouvée
*/
export async function searchCityByLocation(location) {
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${location.latitude}&lon=${location.longitude}`);
        if (!response.ok) {
            throw new Error(`Erreur: ${response.statusText}`);
        }

        const data = await response.json();
        console.log("Données reçues de l'API Nominatim:", data);

        if (data) {
            const display_name = [
                data.address.amenity,
                data.address.county,
                data.address.state,
                data.address.region,
                data.address.postcode,
            ]
                .filter(Boolean)           // Filtrer les valeurs `null`, `undefined`, ou chaînes vides
                .join(', ');
            return {
                display_name: display_name,
                country: data.address.country,
                department: data.address.state,
                code_post: data.address.postcode,
                position: {
                    latitude: data.lat,
                    longitude: data.lon
                },
                city_id: data.place_id
            };
        } else {
            throw new Error("Aucune ville trouvée à cette position.");
        }
    } catch (error) {
        console.error("Erreur lors de la recherche de la ville par localisation:", error);
        return null;
    }
}


/**
 * Rôle: Rechercher des restaurants par ville
 * @param {string} city la ville
 * @returns {Promise<Array>} data des restaurants trouvés
 */
export async function searchRestaurantsByCity(city) {
    console.log("RestaurantByCity:", city);
    try {
        const city_name = city.name;
        const query = `McDonald's, ${city.display_name}`;
        console.log("query:", query);
        const response = await fetch(`${urlNominatim}/search?q=${encodeURIComponent(query)}&format=json&addressdetails=1&limit=5`);
        if (!response.ok) {
            throw new Error(`Erreur: ${response.statusText}`);
        }
        const data = await response.json();
        const restaurants = data.filter(item =>
            item.address.village === city_name ||
            item.address.city === city_name ||
            item.address.town === city_name
        );
        if (restaurants.length === 0) {
            return `Aucun restaurant n'a été trouvé à ${city.name}`;
        }
        return restaurants.map((item) => ({
            name: item.display_name,
            address: item.address.road || item.address.suburb || item.address.village || item.address.city,
            position: {
                latitude: item.lat,
                longitude: item.lon,
            },
            place_id: item.place_id,
        }));
    } catch (error) {
        console.error(error);
        return [];
    }
}