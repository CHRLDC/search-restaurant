import React, { useContext, useEffect } from 'react';
import Button from '../Button/Button';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import { DatasContext } from '../../contextes/DatasContexte.jsx';
import './Map.css';

// Définir l'icône (marqueur de position) par défaut
let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow
});

// Appliquer l'icône par défaut à tous les marqueurs
L.Marker.prototype.options.icon = DefaultIcon;

function LocationCity({ center, selectedRestaurant }) {
    const map = useMap();

    useEffect(() => {
        if (center) {
            map.setView(center, 12);
        }
    }, [center, map]);

    useEffect(() => {
        if (selectedRestaurant) {
            const position = [selectedRestaurant.position.latitude, selectedRestaurant.position.longitude];
            map.flyTo(position, 16); // Zoomer sur le marqueur cliqué avec un zoom de 16
        }
    }, [selectedRestaurant, map]);

    return null;
}

export default function Map({ onPopupEvent }) {
    const { restaurants, selectedCity, updateSelectedRestaurant } = useContext(DatasContext);
    const [selectedRestaurant, setSelectedRestaurant] = React.useState(null);

    const handlePopupEvent = (isOpen, restaurant) => {
        onPopupEvent(isOpen);
        setSelectedRestaurant(isOpen ? restaurant : null);
    };

    return (
        <MapContainer
            style={{ height: "100%", width: "100%" }}
            center={selectedCity ? [selectedCity.position.latitude, selectedCity.position.longitude] : [45.444, 4.390]}
        >
            <LocationCity center={selectedCity ? [selectedCity.position.latitude, selectedCity.position.longitude] : [45.444, 4.390]} selectedRestaurant={selectedRestaurant} />
            <TileLayer url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" />

            {restaurants.length > 0 && restaurants.map((restaurant) => (
                <Marker
                    key={restaurant.place_id}
                    position={[restaurant.position.latitude, restaurant.position.longitude]}
                    eventHandlers={{
                        popupopen: () => handlePopupEvent(true, restaurant),
                        popupclose: () => handlePopupEvent(false, null),
                    }}
                >
                    <Popup>
                        <div className="column">
                            <p>{restaurant.name}</p>
                            <Button
                                className="button"
                                onClick={() => updateSelectedRestaurant(restaurant)}
                            >choisir</Button>
                        </div>
                    </Popup>
                </Marker>
            ))}
        </MapContainer>
    );
}
