import React, { useContext } from 'react';
import Button from '../Button/Button';
import './Overlay.css';
import { DatasContext } from '../../contextes/DatasContexte.jsx';
import { UserLocationContext } from '../../contextes/UserLocationContexte';

export default function Overlay() {
    const { selectedRestaurant } = useContext(DatasContext);
    const { getUserLocation } = useContext(UserLocationContext);

    return (
        <div className="overlay column gap8">
            {selectedRestaurant ? (
                <>
                    <h2>Restaurant sélectionné</h2>
                    <p>{selectedRestaurant.name}</p>
                    <div>
                        <Button>Continuer</Button>
                    </div>
                </>
            ) : (
                <>
                    <h2>Aucun restaurant sélectionné</h2>
                    <Button onClick={getUserLocation}>Restaurants à proximité</Button>
                </>
            )}
        </div>
    );
}
