import './Button.css';

export default function Button({ onClick, children, type = 'button' }) {
    return (
        <button className="custom-button"
            type={type}
            onClick={onClick}
        >
            {children}
        </button>
    );
};
