import React, { useContext } from 'react';
import './SearchBar.css';
import { DatasContext } from '../../contextes/DatasContexte';

export default function SearchBar({ isPopupOpen }) {
    const { cities, handleSearchCitiesByKeyword, handleSearchRestaurantsByCity, setSelectedCity } = useContext(DatasContext);

    const handleSubmit = (event) => {
        event.preventDefault();
        const query = event.target.elements.search.value.trim();
        // Validation de l'entrée utilisateur
        const validQuery = validateInput(query);
        if (validQuery) {
            handleSearchCitiesByKeyword(validQuery);
        }
    };

    const handleCitySelect = async (city) => {
        setSelectedCity(city);
        await handleSearchRestaurantsByCity(city);
    };

    // Fonction de validation du formulaire
    const validateInput = (input) => {
        if (input.length < 2) {
            alert("La recherche doit contenir au moins 2 caractères.");
            return null;
        } else if (input.length > 35) {
            alert("La recherche ne peut pas contenir plus de 35 caractères.");
            return null;
        }
        if (/\d/.test(input)) {
            alert("La recherche ne doit pas contenir de chiffres.");
            return null;
        }
        const sanitizedInput = sanitizeInput(input);
        return sanitizedInput;
    };
    // Fonction de nettoyage
    const sanitizeInput = (input) => {
        // Autorise les lettres, espaces, tirets, apostrophes, et caractères accentués
        const sanitizedInput = input.replace(/[^a-zA-Z\s-'\u00C0-\u017F]/g, '');
        if (sanitizedInput !== input) {
            alert("Certains caractères spéciaux ne sont pas autorisés.");
            return null;
        }
        return sanitizedInput;
    };

    return (
        <div className="searchBar column gap8">
            <form className="column" onSubmit={handleSubmit}>
                <label htmlFor="search">Rechercher un restaurant</label>
                <div className="w100 flex align-center gap8">
                    <input
                        type="text"
                        id="search"
                        placeholder="Où mange t-on ?"
                        aria-label="Rechercher un restaurant"
                    />
                    <button type="submit"></button>
                </div>
            </form>
            {cities.length > 0 && !isPopupOpen && (  // Afficher la liste uniquement si aucune Popup n'est ouverte
                <ul className="column gap8">
                    {cities.map((city) => (
                        <li key={city.city_id} onClick={() => handleCitySelect(city)}>
                            {city.name}, {city.department}, {city.country}
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}
