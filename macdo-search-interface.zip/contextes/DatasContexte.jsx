import React, { createContext, useState } from 'react';
import { searchCitiesByKeyword, searchRestaurantsByCity } from '../datas/datas.jsx';
import { searchCityByLocation } from '../datas/datas';

// Créer le contexte
export const DatasContext = createContext();

// Fournisseur du contexte
export const DatasProvider = ({ children }) => {
    const [cities, setCities] = useState([]);
    const [restaurants, setRestaurants] = useState([]);
    const [selectedCity, setSelectedCity] = useState(null);
    const [selectedRestaurant, setSelectedRestaurant] = useState(null);

    const handleSearchCitiesByKeyword = async (keyword) => {
        const results = await searchCitiesByKeyword(keyword);
        setCities(results);
    };

    const handleSearchRestaurantsByCity = async (city) => {
        const results = await searchRestaurantsByCity(city);
        setRestaurants(results);
    };

    const updateSelectedRestaurant = (restaurant) => {
        setSelectedRestaurant(restaurant);
    };

    const getUserCity = async (location) => {
        const city = await searchCityByLocation(location);
        if (city) {
            setSelectedCity(city);
            // Recherche des restaurants dans la ville trouvée
            const restaurantsFound = await searchRestaurantsByCity(city);
            setRestaurants(restaurantsFound);
        }
    };

    return (
        <DatasContext.Provider
            value={{
                cities,
                getUserCity,
                restaurants,
                selectedCity,
                setSelectedCity,
                selectedRestaurant,
                handleSearchCitiesByKeyword,
                setSelectedRestaurant,
                updateSelectedRestaurant,
                handleSearchRestaurantsByCity,
            }}
        >
            {children}
        </DatasContext.Provider>
    );
};
