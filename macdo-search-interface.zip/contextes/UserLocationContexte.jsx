import React, { createContext, useState, useContext } from 'react';
import { DatasContext } from './DatasContexte';
// Créer le contexte
export const UserLocationContext = createContext();

// Fournisseur du contexte
export const UserLocationProvider = ({ children }) => {
    const [userLocation, setUserLocation] = useState(null);
    const [locationError, setLocationError] = useState(null);
    const { getUserCity } = useContext(DatasContext);

    const getUserLocation = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const location = {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                    };
                    setUserLocation(location);
                    setLocationError(null);
                    getUserCity(location); // Appeler getUserCity après avoir obtenu la localisation
                },
                (error) => {
                    setLocationError(error.message);
                }
            );
        } else {
            setLocationError("La géolocalisation n'est pas supportée par ce navigateur.");
        }
    };

    return (
        <UserLocationContext.Provider value={{ userLocation, locationError, getUserLocation }}>
            {children}
        </UserLocationContext.Provider>
    );
};
